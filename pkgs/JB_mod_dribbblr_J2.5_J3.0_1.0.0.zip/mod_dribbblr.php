<?php
/**
 *
 *
 * @package   mod_dribbblr
 * copyright Siege21.com/Antony Doyle
 * @license GPL3
 */

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once(dirname(__FILE__).DS.'helper.php');

require(JModuleHelper::getLayoutPath('mod_dribbblr'));

