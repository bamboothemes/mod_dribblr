mod_dribbblr
================

A simple Joomla module for displaying your Dribbble shots on your site.

Compatible with Joomla 2.5 and Joomla 3+.

This is a fork of the original adaptation of the script by Antony Doyle (https://github.com/antonydoyle/mod_dribbleshots).

This version is built specifically for templates using T3 or Bootstrap.

Makes use of jQuery and heavy lifting is done by jribble - https://github.com/tylergaw/jribbble - saved me a lot of effort! So, thanks to Tyler Gaw for that. 


